//
//  workingSetManagerModel.swift
//  workingSetProject_v2
//
//  Created by Osa on 7/3/16.
//  Copyright © 2016 Osa. All rights reserved.
//

class workingSetManagerModel{
    
    func addNewWD(){
        print("Action performed.")
    }
    
    func openWD(){
        print("Action performed.")
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
