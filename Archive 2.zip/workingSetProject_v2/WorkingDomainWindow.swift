//
//  WorkingDomainWindow.swift
//  workingSetProject_v2
//
//  Created by Osa on 7/23/16.
//  Copyright © 2016 Osa. All rights reserved.
//

import Cocoa

class WorkingDomainWindow: NSWindow {
    
  
    
}
